import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Main2014302580368 {
	public static void main(String[]args){
	try{
	Document doc = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Li%20_%20Zhen").get(); 
	 Element content = doc.getElementsByClass("details").first();
	 Element content1 = doc.getElementsByClass("details").last();
	 String con=content.text();
	 String con1=content1.text();
	 Pattern pattern=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
	 Pattern pattern1=Pattern.compile("[0-9]{3}-[0-9]{8}");
	 Matcher matcher = pattern.matcher(con);
	 Matcher matcher1 = pattern1.matcher(con);
	 StringBuffer sb = new StringBuffer(); 
	 FileWriter fileWriter=new FileWriter("G:\\javaʵ��\\Assignment2\\Result.txt");
	 fileWriter.write("��ȡ�ĺ�������䣺\r\n");
	 if(matcher.find())
		 fileWriter.write(matcher.group());
	 fileWriter.write("\r\n");
	 if(matcher1.find())
		 fileWriter.write(matcher1.group());
	 fileWriter.write("\r\n");
	 fileWriter.write(con);
	 fileWriter.write(con1);
	 fileWriter.flush();
	 fileWriter.close();
	}catch(IOException e) { 
        // TODO Auto-generated catch block 
	    e.printStackTrace();
	    } 
}
}